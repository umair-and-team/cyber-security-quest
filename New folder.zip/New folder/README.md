# CyberQuest 2.0

An interactive, browser-based cybersecurity quiz with animated background, randomized questions, timers, percentage scoring, a local leaderboard, and a downloadable completion certificate.

## Quick Start

- Open `index.html` in a modern browser (Chrome/Edge/Firefox).
- Enter your details and start the quiz.
- Answer 10 randomized questions (20s each). Timeout ends the run.
- See your final score and personalized message; optionally get a certificate.
- Click Continue to return to the landing page; leaderboard updates automatically.

No build step required; runs as static files.

## Project Structure

```
/ (project root)
  index.html              # Landing + Quiz UI
  style.css               # Styles (dark theme, animations)
  script.js               # Game logic, leaderboard, certificate hook
  /public
    certificate.html      # Certificate renderer page
    certificate.css       # Certificate styling
    certificate-render.js # Canvas drawing + PNG download
    /assets
      certificate-bg.png  # Certificate background image
```

## Features

- Fixed animated background: glowing dots linked by lines
- Landing: user details, awareness and measures sections
- Quiz engine
  - 50 MCQs in the bank; 10 random per run
  - Options shuffled per question
  - 20s timer per question; 5s hurry warning
  - Timeout ends the run; wrong answers do not stop the run
- Scoring: percentage = `round((correct / total) * 100)`
- Final popup
  - Personalized title with username
  - Below 75%: encouragement; 75%+: congrats
  - Badges: 🥇 Strong Defender (≥75%), 🏆 Flawless (100%)
  - Buttons: Get Certificate, Continue (back to landing)
- Leaderboard
  - Stored in localStorage key `cq_leaderboard`
  - Ranked by highest percentage; ties by earliest time
  - Shown on landing page only

## Certificate

- Background image: `public/assets/certificate-bg.png`
  - Recommended ~1920×1280 (3:2). Replace the file to customize.
- The certificate page (`public/certificate.html`) takes query params:
  - `name` — user’s display name
  - `score` — percentage (e.g., 85)
- The app opens it from the final popup and the page triggers PNG download.

## Configuration

- Change question count: edit `buildLevels()` in `script.js`.
- Timer per MCQ: adjust `time` per entry returned in `buildLevels()` (default 20).
- Score messages/badges: edit `showScorePopup()` and `awardFinalBadge()`.
- Leaderboard size: change the cap in `saveScoreToLeaderboard()` (default 50).

## Troubleshooting

- Certificate page won’t open
  - Allow pop-ups for the page
  - Ensure `public/certificate.html` and `public/assets/certificate-bg.png` exist
- Leaderboard doesn’t update
  - DevTools → Application/Storage → Local Storage → `cq_leaderboard`
  - Reset with `localStorage.removeItem('cq_leaderboard')`
- Running via local server (optional)
  - Python: `python -m http.server 8080` → open `http://localhost:8080/`
  - Node: `npx serve .`

## License

Provided as-is for educational purposes. Replace content (questions, images, styles) as needed for your use case.




