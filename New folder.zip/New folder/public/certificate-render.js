(function(){
  const params = new URLSearchParams(location.search);
  const name = params.get('name') || 'Player';
  const score = params.get('score') || '0';

  const canvas = document.getElementById('certCanvas');
  const ctx = canvas.getContext('2d');

  // Draw background image (optional)
  const bg = new Image();
  bg.onload = () => {
    try { ctx.drawImage(bg, 0, 0, canvas.width, canvas.height); } catch {}
    drawCertificate();
    autoDownload();
  };
  bg.onerror = () => { drawCertificate(); autoDownload(); };
  bg.src = 'assets/certificate-bg.png';

  function drawCertificate(){
    // Semi-transparent overlay for readability
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.fillRect(80, 80, canvas.width-160, canvas.height-160);

    // Title
    ctx.fillStyle = '#222';
    ctx.textAlign = 'center';
    drawText('CERTIFICATE', 120, 380, 'serif');
    drawText('OF ACHIEVEMENT', 80, 480, 'serif');

    // Subtitle
    drawText('This certifies that', 38, 600, 'sans-serif');

    // Name
    drawText(name, 110, 760, 'serif');

    // Body line
    drawText('has successfully completed the test with', 38, 880, 'sans-serif');

    // Score
    drawText(`${score}%`, 110, 1030, 'serif');
  }

  function drawText(text, size, y, family){
    ctx.font = `${size}px ${family || 'sans-serif'}`;
    ctx.fillStyle = '#222';
    ctx.fillText(text, canvas.width/2, y);
  }

  function autoDownload(){
    const a = document.createElement('a');
    a.download = `Certificate-${name}-${score}.png`;
    a.href = canvas.toDataURL('image/png');
    setTimeout(()=>a.click(), 250);
  }

  document.getElementById('downloadBtn').addEventListener('click', autoDownload);
  document.getElementById('printBtn').addEventListener('click', () => window.print());
})();





