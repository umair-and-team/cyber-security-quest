// Utility
function shuffle(array) {
  const a = array.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Game state
const state = {
  levelIndex: 0,
  score: 0,
  answered: false,
  timerId: null,
  timeLeft: 0,
  intervals: []
};

// DOM elements
const levelEl = document.getElementById("level");
const scoreEl = document.getElementById("score");
const badgeEl = document.getElementById("badge");
const storyEl = document.getElementById("story");
const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const feedbackEl = document.getElementById("feedback");
const startBtn = document.getElementById("startBtn");
const nextBtn = document.getElementById("nextBtn");
const resetBtn = document.getElementById("resetBtn");
const progressBar = document.getElementById("progress-bar");
const timerBar = document.getElementById("timer-bar");
const timerText = document.getElementById("timer-text");
const popup = document.getElementById("popup");
const popupTitle = document.getElementById("popup-title");
const popupText = document.getElementById("popup-text");
const popupContinue = document.getElementById("popup-continue");
const confettiRoot = document.getElementById("confetti");
const popupCert = document.getElementById("popup-cert");
const leaderboardList = document.getElementById("leaderboard");
const appRoot = document.getElementById("app");
const landingRoot = document.getElementById("landing");
const userSubmit = document.getElementById("userSubmit");
const userNameInput = document.getElementById("userName");
const userAgeInput = document.getElementById("userAge");
const userAreaInput = document.getElementById("userArea");
const userErrorEl = document.getElementById("userError");

startBtn.addEventListener("click", startGame);
nextBtn.addEventListener("click", handleNext);
resetBtn.addEventListener("click", resetGame);
userSubmit.addEventListener("click", handleUserSubmit);

// Show landing on load
document.addEventListener("DOMContentLoaded", () => {
  if (landingRoot && appRoot) {
    landingRoot.style.display = "block";
    appRoot.style.display = "none";
  }
  startBtn.disabled = true; // guarded by user submission
  // Landing scroll animation
  const detailsCard = document.getElementById("detailsCard");
  const awarenessWrap = document.querySelector(".awareness-wrap");
  const cyberBox = document.getElementById("cyberBox");
  // Render leaderboard on landing load
  renderLeaderboard();

  // Test certificate button
  const testBtn = document.getElementById('testCertBtn');
  if (testBtn) {
    testBtn.addEventListener('click', () => {
      const name = (userNameInput && userNameInput.value.trim()) || 'Player';
      openCertificate(name, 85);
    });
  }
  // compute details height for placement swap
  function setDetailsHeightVar() {
    if (!detailsCard) return;
    const h = detailsCard.offsetHeight || 0;
    document.documentElement.style.setProperty('--detailsH', h + 'px');
  }
  setDetailsHeightVar();
  window.addEventListener('resize', setDetailsHeightVar);
  window.addEventListener("scroll", () => {
    const y = window.scrollY;
    const threshold = 120; // px before we transition
    if (y > threshold) {
      if (detailsCard) detailsCard.classList.add("fade-back");
      if (cyberBox) cyberBox.classList.add("fade-back");
      // no slide/placement change
    } else {
      if (detailsCard) detailsCard.classList.remove("fade-back");
      if (cyberBox) cyberBox.classList.remove("fade-back");
      // no slide/placement change
    }
  });
});

// Levels config — 50 MCQs
const mcqBank = [
  { question: "Spot the phishing email!", options: ["Campus IT: 'Reset via portal only.'", "'Verify now': http://secure-login.example.ru", "Advisor: 'Meeting at 2pm—see calendar.'"], answerIndex: 1, explain: "Suspicious domain and urgency = red flag." },
  { question: "Which link is safest?", options: ["http://bank-login.com", "https://bank.com", "http://bank.com.login.cn"], answerIndex: 1, explain: "HTTPS and correct domain." },
  { question: "Strongest password option?", options: ["Password1", "Qw!9z$3mR2", "letmein123"], answerIndex: 1, explain: "Use length + mix of cases, numbers, symbols." },
  { question: "Attachment to avoid?", options: ["report.pdf", "grades.xlsx", "invoice.exe"], answerIndex: 2, explain: ".exe can run code—dangerous from unknown senders." },
  { question: "Safest Wi‑Fi at a cafe?", options: ["Open Free Wi‑Fi", "CafeSecure (WPA2)", "CafeGuest (no password)"], answerIndex: 1, explain: "Prefer encrypted networks (WPA2/WPA3)." },
  { question: "Best way to verify caller from 'bank'?", options: ["Call back via bank's official number", "Share details quickly", "Ask for OTP"], answerIndex: 0, explain: "Independently call the published number." },
  { question: "URL looks like bank.com but actually?", options: ["bank.com", "bank.com.security-check.io", "security-bank.com"], answerIndex: 1, explain: "Subdomain tricks—real domain is after the last dot before TLD." },
  { question: "Safe place to store passwords?", options: ["Browser screenshot", "Password manager", "Notes app"], answerIndex: 1, explain: "Use a reputable password manager." },
  { question: "MFA that’s strongest?", options: ["SMS", "Authenticator app", "Email code"], answerIndex: 1, explain: "App or security keys beat SMS in most cases." },
  { question: "Good example of phishing?", options: ["noreply@university.edu", "billing@university.support-pay.io", "helpdesk@dept.university.edu"], answerIndex: 1, explain: "Look at the real domain." },
  { question: "Device update policy?", options: ["Delay updates for months", "Install updates promptly", "Disable updates"], answerIndex: 1, explain: "Patching fixes security holes." },
  { question: "Public USB charging risk?", options: ["Juice jacking", "Battery swelling", "Screen burn-in"], answerIndex: 0, explain: "Malicious ports can inject data." },
  { question: "Before clicking a link you should…", options: ["Hover to preview URL", "Trust the display text", "Click quickly"], answerIndex: 0, explain: "Preview the destination domain." },
  { question: "Red flag in invoices?", options: ["Exact company name", "Urgent payment via gift cards", "PO reference"], answerIndex: 1, explain: "Gift cards are a common scam." },
  { question: "Good password trait?", options: ["Short memorable word", "Unique long passphrase", "Birthday"], answerIndex: 1, explain: "Length and uniqueness matter." },
  { question: "If a site has HTTPS…", options: ["It is guaranteed safe", "It encrypts the connection", "It cannot be phished"], answerIndex: 1, explain: "HTTPS ≠ trust; it’s encryption only." },
  { question: "Lost phone with authenticator?", options: ["Share codes with a friend", "Use backup codes and revoke old device", "Ignore"], answerIndex: 1, explain: "Backup codes + revoke device." },
  { question: "QR code in email…", options: ["Always safe", "Could be phishing", "Must be from IT"], answerIndex: 1, explain: "Attackers embed malicious QR links." },
  { question: "Secure file sharing?", options: ["Random third‑party link", "Official org tool with access controls", "Personal social media"], answerIndex: 1, explain: "Use sanctioned tools with permissions." },
  { question: "Should you reuse passwords?", options: ["Yes across all", "Only for social", "No—never reuse"], answerIndex: 2, explain: "Reuse enables credential stuffing." },
  { question: "Strong passphrase example", options: ["BlueCar12!", "sun.walks-rain?forest 2025", "Qwerty1"], answerIndex: 1, explain: "Long multi-word phrases are better." },
  { question: "Cleaning phishing from inbox", options: ["Reply and ask", "Report/mark as phishing", "Forward to friends"], answerIndex: 1, explain: "Report and avoid engaging." },
  { question: "Social media privacy", options: ["Public by default", "Review privacy settings", "Share birthdate openly"], answerIndex: 1, explain: "Reduce exposed data." },
  { question: "VPN helps with…", options: ["Malware removal", "Encrypting traffic on untrusted Wi‑Fi", "Password strength"], answerIndex: 1, explain: "Protects traffic on open networks." },
  { question: "What is smishing?", options: ["Phone call scam", "SMS phishing", "USB attack"], answerIndex: 1, explain: "SMS‑based phishing." },
  { question: "Ransomware typically…", options: ["Steals monitors", "Encrypts files and demands payment", "Slows network"], answerIndex: 1, explain: "Encrypts and ransoms data." },
  { question: "Safe to install apps from…", options: ["Unknown sites", "Official app stores", "Email attachments"], answerIndex: 1, explain: "Prefer vetted stores." },
  { question: "Phishing pretext often includes…", options: ["Urgency and threats", "Long privacy policy", "High-res logo only"], answerIndex: 0, explain: "Pressure tactics are common." },
  { question: "You receive OTP request from 'IT'", options: ["Share it", "Never share; report", "Give half of it"], answerIndex: 1, explain: "OTPs are secret—report." },
  { question: "Strongest recovery method", options: ["Only email", "Multiple factors + backup codes", "None"], answerIndex: 1, explain: "Diverse recovery methods." },
  { question: "USB received as gift", options: ["Use immediately", "Treat as suspicious", "Plug into office PC"], answerIndex: 1, explain: "Could contain malware." },
  { question: "Phishing domain lookalike", options: ["university.edu", "university‑support.com", "edu.university"], answerIndex: 1, explain: "Unrelated domain trick." },
  { question: "Cloud document request asks login", options: ["Enter creds in page", "Verify sender and URL", "Ignore always"], answerIndex: 1, explain: "Verify before entering creds." },
  { question: "Data minimization means…", options: ["Collect more data", "Keep the least necessary", "Share publicly"], answerIndex: 1, explain: "Limit what you store/share." },
  { question: "Should you post boarding pass?", options: ["Yes for fun", "No—contains sensitive codes", "Only after flight"], answerIndex: 1, explain: "Barcodes leak info." },
  { question: "Email from boss asks gift cards", options: ["Buy and send codes", "Verify via another channel", "Reply with PINs"], answerIndex: 1, explain: "Confirm via trusted path." },
  { question: "Indicators of compromise include…", options: ["System updates", "Unexpected encryption notes", "New wallpaper"], answerIndex: 1, explain: "Ransom notes are a clue." },
  { question: "Phishing safe action", options: ["Download zip", "Open .exe", "Report and delete"], answerIndex: 2, explain: "Don’t open unknown files." },
  { question: "Good Wi‑Fi practice", options: ["Auto‑join all networks", "Forget risky networks", "Share hotspot to strangers"], answerIndex: 1, explain: "Reduce accidental joins." },
  { question: "Browser extension safety", options: ["Install all recommended", "Review permissions & reviews", "Ignore updates"], answerIndex: 1, explain: "Check permissions carefully." },
  { question: "Password sharing at work", options: ["Allowed via chat", "Avoid—use shared vaults", "Write on sticky notes"], answerIndex: 1, explain: "Use access sharing, not sharing passwords." },
  { question: "Email attachment to trust", options: ["invoice.exe", "report.pdf from known sender via portal", "random.zip"], answerIndex: 1, explain: "Prefer portal-delivered docs." },
  { question: "Phishing page often asks for…", options: ["Username & password", "Wallpaper", "Screen brightness"], answerIndex: 0, explain: "Credential harvesting." },
  { question: "Good backup practice", options: ["Single copy on same device", "3-2-1 strategy", "No backups"], answerIndex: 1, explain: "Multiple copies and media." },
  { question: "Link shorteners", options: ["Always safe", "Can hide malicious links", "Government only"], answerIndex: 1, explain: "Preview or avoid when unsure." },
  { question: "If you clicked a bad link", options: ["Stay calm, report to IT, change passwords if needed", "Hide it", "Send to friends"], answerIndex: 0, explain: "Respond quickly and report." },
  { question: "Lock your device", options: ["Not necessary", "Always when away", "Only at home"], answerIndex: 1, explain: "Prevent shoulder surfing/access." },
  { question: "Phishing via calendar invites", options: ["Impossible", "Possible—review details before accepting", "Always accept"], answerIndex: 1, explain: "Check organizer and link." },
  { question: "Credential stuffing defense", options: ["Reuse passwords", "MFA + unique passwords", "Disable MFA"], answerIndex: 1, explain: "Unique creds + MFA." },
  { question: "Safe screen sharing", options: ["Share entire desktop with all apps", "Share only needed window", "Share passwords"], answerIndex: 1, explain: "Minimize exposure." },
  { question: "When in doubt about an email", options: ["Verify via official channel", "Click link to check", "Reply with data"], answerIndex: 0, explain: "Out-of-band verification." }
];

function buildLevels() {
  // Pick 10 random MCQs for each run
  const picks = shuffle(mcqBank).slice(0, 10).map(d => ({ type: "mcq", data: d, time: 20 }));
  return picks;
}

let levels = buildLevels();
state.atEndPopup = false;
state.user = null;

function startGame() {
  clearAllIntervals();
  levels = buildLevels();
  state.levelIndex = 0;
  state.score = 0;
  state.results = [];
  badgeEl.textContent = "";
  startBtn.disabled = true;
  resetBtn.disabled = false;
  nextBtn.disabled = true;
  if (state.user && state.user.username) {
    storyEl.textContent = `ShadowByte is on the move, ${state.user.username}! Stay sharp!`;
  } else {
    storyEl.textContent = "ShadowByte is on the move... Stay sharp!";
  }
  renderCurrent();
}

function resetGame() {
  // Immediately start a new run
  clearTimer();
  clearAllIntervals();
  startGame();
}

function handleNext() {
  if (state.levelIndex < levels.length - 1) {
    state.levelIndex += 1;
    renderCurrent();
  } else {
    endGame();
  }
}

function endGame() {
  clearTimer();
  // Compute final score based on recorded results (10 per correct)
  const correctCount = (state.results || []).filter(Boolean).length;
  const total = levels.length || 1;
  // Score as percentage
  state.score = Math.round((correctCount / total) * 100);
  updateProgress();
  feedbackEl.textContent = awardFinalBadge();
  nextBtn.disabled = true;
  startBtn.disabled = true;
  resetBtn.disabled = false;
  // Show final scoreboard popup instead of mid-quiz
  saveScoreToLeaderboard();
  renderLeaderboard();
  showScorePopup("Round Complete", true, true);
}

function renderCurrent() {
  clearTimer();
  clearAllIntervals();
  state.answered = false;
  const levelNum = state.levelIndex + 1;
  levelEl.textContent = `Level: ${levelNum}`;
  nextBtn.disabled = true;
  const lvl = levels[state.levelIndex];
  updateProgress();

  if (lvl.type === "mcq") renderMcq(lvl);
  if (lvl.type === "dragdrop") renderDragDrop(lvl);
  if (lvl.type === "chat") renderChat(lvl);

  startTimer(lvl.time);
}

function updateProgress() {
  const percent = (state.levelIndex / (levels.length || 1)) * 100;
  progressBar.style.width = `${percent}%`;
  if (scoreEl) {
    // Keep score hidden during gameplay
  }
}

function startTimer(seconds) {
  state.timeLeft = seconds;
  timerText.textContent = `${state.timeLeft}s`;
  timerBar.style.width = "100%";
  const total = seconds;
  state.timerId = setInterval(() => {
    state.timeLeft -= 1;
    const pct = Math.max(0, (state.timeLeft / total) * 100);
    timerBar.style.width = `${pct}%`;
    timerText.textContent = `${state.timeLeft}s`;
    if (state.timeLeft === 5 && !state.answered) {
      feedbackEl.textContent = "⏳ Hurry up! 5 seconds left!";
      feedbackEl.classList.add("animate-pulse");
      setTimeout(() => feedbackEl.classList.remove("animate-pulse"), 420);
    }
    if (state.timeLeft <= 0) {
      clearTimer();
      if (!state.answered) {
        feedbackEl.textContent = "⏱️ Time's up!";
        feedbackEl.classList.add("animate-shake");
        setTimeout(() => feedbackEl.classList.remove("animate-shake"), 420);
        if (!state.results) state.results = [];
        state.results[state.levelIndex] = false;
        endGame();
      }
    }
  }, 1000);
  state.intervals.push(state.timerId);
}

function clearTimer() {
  if (state.timerId) clearInterval(state.timerId);
  state.timerId = null;
}

function clearAllIntervals() {
  if (state.intervals && state.intervals.length) {
    state.intervals.forEach(id => clearInterval(id));
  }
  state.intervals = [];
}

function lockLevel(correct) {
  state.answered = true;
  nextBtn.disabled = false;
  // Pause timer only on incorrect answers
  if (!correct) {
    clearTimer();
  }
  // Record result for later scoring
  if (!state.results) state.results = [];
  state.results[state.levelIndex] = !!correct;
  if (correct) {
    badgeFast();
    feedbackEl.classList.add("animate-pulse");
    setTimeout(() => feedbackEl.classList.remove("animate-pulse"), 360);
    // Auto-advance to next question after short beat
    clearTimer();
    setTimeout(() => {
      if (!state.answered) return; // safety
      handleNext();
    }, 600);
  } else {
    feedbackEl.classList.add("animate-shake");
    setTimeout(() => feedbackEl.classList.remove("animate-shake"), 420);
    // Auto-advance to next question without popup
    setTimeout(() => {
      if (!state.answered) return;
      handleNext();
    }, 700);
  }
  updateProgress();
}

// Popup scoreboard
function showScorePopup(title, celebrate = true, isFinal = false) {
  clearTimer();
  if (typeof clearAllIntervals === "function") clearAllIntervals();
  state.atEndPopup = !!isFinal;
  // Tailored messaging based on percentage
  if (isFinal) {
    const name = (state.user && state.user.username) ? state.user.username : 'Player';
    if (state.score >= 75) {
      popupTitle.textContent = `Great job, ${name}! You're Cyber‑Aware 🚀`;
    } else {
      popupTitle.textContent = `Nice try, ${name}! Keep training 💪`;
    }
    popupText.textContent = `Your score: ${state.score}%`;
    if (popupCert) popupCert.style.display = '';
  } else {
    popupTitle.textContent = title;
    const total = levels.length || 1;
    popupText.textContent = `Score: ${state.score}% | Level ${state.levelIndex + 1} / ${total}`;
    if (popupCert) popupCert.style.display = 'none';
  }
  // Popup should not show leaderboard
  popup.classList.add("show");
  popup.setAttribute("aria-hidden", "false");
  popupContinue.textContent = isFinal ? "Play Again" : "Continue";
  triggerConfetti(celebrate ? 40 : 20);
}

function openCertificate(name, percent){
  const base = new URL('.', window.location.href);
  const url = new URL('public/certificate.html', base);
  url.searchParams.set('name', name || 'Player');
  url.searchParams.set('score', String(percent ?? 0));
  window.open(url.href, '_blank');
}

// Leaderboard (localStorage)
function loadLeaderboard() {
  try {
    const raw = localStorage.getItem('cq_leaderboard');
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}

function saveLeaderboard(entries) {
  try { localStorage.setItem('cq_leaderboard', JSON.stringify(entries)); } catch {}
}

function saveScoreToLeaderboard() {
  const username = (state.user && state.user.username) ? state.user.username : 'Player';
  const score = state.score || 0; // percentage
  const date = Date.now();
  const entries = loadLeaderboard();
  entries.push({ username, score, date });
  // sort: highest score desc, then earliest date
  entries.sort((a, b) => b.score - a.score || a.date - b.date);
  // cap to 50 entries
  saveLeaderboard(entries.slice(0, 50));
}

function renderLeaderboard() {
  if (!leaderboardList) return;
  const entries = loadLeaderboard().slice(0, 10);
  if (!entries.length) {
    leaderboardList.innerHTML = '<li>No scores yet.</li>';
    return;
  }
  leaderboardList.innerHTML = entries
    .map((e, i) => `<li><strong>#${i + 1}</strong> ${escapeHtml(e.username)} — ${e.score}%</li>`)
    .join('');
}

function renderLeaderboardHtml(limit = 10) {
  const entries = loadLeaderboard();
  const top = entries.slice(0, limit);
  if (!top.length) return '<li>No scores yet.</li>';
  return top.map((e, i) => `<li><strong>#${i + 1}</strong> ${escapeHtml(e.username)} — ${e.score}</li>`).join('');
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[c]));
}

function hideScorePopup() {
  popup.classList.remove("show");
  popup.setAttribute("aria-hidden", "true");
  clearConfetti();
}

popupContinue.addEventListener("click", () => {
  hideScorePopup();
  if (state.atEndPopup) {
    // Return to landing page instead of auto-restarting
    if (landingRoot && appRoot) {
      appRoot.style.display = "none";
      landingRoot.style.display = "block";
    }
    state.atEndPopup = false;
    renderLeaderboard();
  } else {
    handleNext();
  }
});

if (popupCert) {
  popupCert.addEventListener('click', () => {
    const name = (state.user && state.user.username) ? state.user.username : 'Player';
    openCertificate(name, state.score);
  });
}

function triggerConfetti(pieces) {
  clearConfetti();
  const colors = ["#4caf50", "#ff5722", "#03a9f4", "#ffd54f", "#e91e63", "#2dd4bf"]; 
  const width = confettiRoot.clientWidth || 480;
  for (let i = 0; i < pieces; i++) {
    const s = document.createElement("span");
    s.className = "confetti-piece";
    const left = Math.random() * width;
    const delay = Math.random() * 200;
    const bg = colors[Math.floor(Math.random() * colors.length)];
    s.style.left = `${left}px`;
    s.style.background = bg;
    s.style.animationDelay = `${delay}ms`;
    confettiRoot.appendChild(s);
    // auto cleanup
    setTimeout(() => s.remove(), 1300 + delay);
  }
}

function clearConfetti() {
  if (!confettiRoot) return;
  while (confettiRoot.firstChild) confettiRoot.removeChild(confettiRoot.firstChild);
}

function badgeFast() {
  // Earn if answered with >= 13s left (roughly under 7s on 20s timer)
  if (state.timeLeft >= 13) {
    badgeEl.textContent = "🏅 Fast Thinker";
  }
}

function awardFinalBadge() {
  if (state.score >= 100) {
    badgeEl.textContent = "🏆 Flawless";
    return "Badge unlocked: Flawless!";
  }
  if (state.score >= 75) {
    badgeEl.textContent = "🥇 Strong Defender";
    return "Strong Defender badge earned!";
  }
  badgeEl.textContent = "";
  return "Keep going—every run builds your skills.";
}

// Handle user details
function handleUserSubmit() {
  const username = (userNameInput.value || "").trim();
  const age = parseInt(userAgeInput.value, 10);
  const area = (userAreaInput.value || "").trim();

  if (!username) {
    userErrorEl.textContent = "Please enter a username.";
    return;
  }
  if (!(age >= 5 && age <= 120)) {
    userErrorEl.textContent = "Please enter a valid age (5-120).";
    return;
  }
  if (!area) {
    userErrorEl.textContent = "Please enter your area (city/region).";
    return;
  }

  state.user = { username, age, area };
  // Navigate to quiz page and start
  if (landingRoot && appRoot) {
    landingRoot.style.display = "none";
    appRoot.style.display = "block";
  }
  startGame();
}

// Renderers
function renderMcq(lvl) {
  const d = lvl.data;
  questionEl.textContent = d.question;
  feedbackEl.textContent = "";
  optionsEl.innerHTML = "";
  const shuffled = shuffle(d.options.map((t, i) => ({ t, i })));
  shuffled.forEach(({ t, i }) => {
    const btn = document.createElement("button");
    btn.className = "option-btn";
    btn.textContent = t;
    btn.addEventListener("click", () => {
      if (state.answered) return;
      const isCorrect = i === d.answerIndex;
      feedbackEl.textContent = isCorrect ? `✅ Correct! ${d.explain}` : `❌ Wrong. ${d.explain}`;
      Array.from(optionsEl.children).forEach((b) => (b.disabled = true));
      if (isCorrect) btn.classList.add("correct"); else btn.classList.add("wrong");
      lockLevel(isCorrect);
    });
    optionsEl.appendChild(btn);
  });
}

function renderDragDrop(lvl) {
  questionEl.textContent = "Build a strong password: drag items into the box (8+ chars, include number and symbol).";
  feedbackEl.textContent = "";
  optionsEl.innerHTML = "";

  const tray = document.createElement("div");
  tray.className = "dnd-tray";
  const pool = shuffle(["A","b","C","d","1","7","!","?","x","Z","9","#"]);
  pool.forEach(ch => {
    const span = document.createElement("span");
    span.className = "chip";
    span.textContent = ch;
    span.draggable = true;
    span.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", ch);
    });
    tray.appendChild(span);
  });

  const drop = document.createElement("div");
  drop.className = "dropzone";
  const preview = document.createElement("span");
  preview.className = "pwd-preview";
  preview.textContent = "";
  drop.appendChild(preview);

  let current = "";
  drop.addEventListener("dragover", (e) => e.preventDefault());
  drop.addEventListener("drop", (e) => {
    e.preventDefault();
    const ch = e.dataTransfer.getData("text/plain");
    current += ch;
    preview.textContent = current;
    drop.classList.add("filled");
  });

  const submit = document.createElement("button");
  submit.className = "option-btn";
  submit.textContent = "Submit Password";
  submit.addEventListener("click", () => {
    if (state.answered) return;
    const strong = current.length >= 8 && /\d/.test(current) && /[^\w]/.test(current);
    feedbackEl.textContent = strong ? "✅ Strong password!" : "❌ Too weak. Add length, a number, and a symbol.";
    submit.disabled = true;
    tray.querySelectorAll(".chip").forEach(c => c.draggable = false);
    lockLevel(strong);
  });

  optionsEl.appendChild(tray);
  optionsEl.appendChild(drop);
  optionsEl.appendChild(submit);
}

function renderChat(lvl) {
  questionEl.textContent = "Social engineering: Suspicious DM arrives...";
  feedbackEl.textContent = "";
  optionsEl.innerHTML = "";

  const chat = document.createElement("div");
  chat.className = "chat";
  optionsEl.appendChild(chat);

  const messages = [
    { who: "them", text: "Hey, IT here. Need your OTP to secure your account." },
    { who: "them", text: "Quick, it expires in 30 seconds!" }
  ];

  function addMsg(who, text) {
    const div = document.createElement("div");
    div.className = `msg ${who === "them" ? "from-them" : "from-you"}`;
    div.textContent = text;
    chat.appendChild(div);
  }

  let idx = 0;
  const timer = setInterval(() => {
    if (idx < messages.length) {
      addMsg(messages[idx].who, messages[idx].text);
      idx += 1;
    } else {
      clearInterval(timer);
      const actions = document.createElement("div");
      actions.className = "options";
      const a = document.createElement("button");
      a.className = "option-btn";
      a.textContent = "Ignore & report";
      const b = document.createElement("button");
      b.className = "option-btn";
      b.textContent = "Share OTP";
      actions.appendChild(a);
      actions.appendChild(b);
      optionsEl.appendChild(actions);

      a.addEventListener("click", () => {
        if (state.answered) return;
        addMsg("you", "I will report this.");
        feedbackEl.textContent = "✅ Correct: Never share OTP.";
        a.classList.add("correct");
        b.disabled = true;
        lockLevel(true);
      });
      b.addEventListener("click", () => {
        if (state.answered) return;
        addMsg("you", "Here's my OTP...");
        feedbackEl.textContent = "❌ Wrong: This is a scam.";
        b.classList.add("wrong");
        a.disabled = true;
        lockLevel(false);
      });
    }
  }, 700);
  state.intervals.push(timer);
}



// Animated background - drifting glowing dots with linking lines (previous style)
(function initBgCanvas() {
  const canvas = document.getElementById("bg-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  let width = 0, height = 0, device = Math.min(window.devicePixelRatio || 1, 2);
  let particles = [];
  const linkDistance = 120; // px
  const baseCount = 90; // target particle count for 1280x720 approx

  function resize() {
    width = canvas.clientWidth;
    height = canvas.clientHeight;
    canvas.width = Math.floor(width * device);
    canvas.height = Math.floor(height * device);
    ctx.setTransform(device, 0, 0, device, 0, 0);
    // Rebuild particles to match new area density
    const area = width * height;
    const density = Math.max(40, Math.floor(baseCount * (area / (1280 * 720))));
    buildParticles(density);
  }

  function buildParticles(count) {
    particles = new Array(count).fill(0).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      r: 1 + Math.random() * 1.6
    }));
  }

  function step() {
    ctx.clearRect(0, 0, width, height);

    // draw links
    ctx.lineWidth = 1;
    for (let i = 0; i < particles.length; i++) {
      const a = particles[i];
      for (let j = i + 1; j < particles.length; j++) {
        const b = particles[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const d2 = dx * dx + dy * dy;
        const max2 = linkDistance * linkDistance;
        if (d2 < max2) {
          const t = 1 - d2 / max2; // 0..1
          ctx.strokeStyle = `rgba(100, 190, 255, ${0.12 * t})`;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    }

    // draw particles and update
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      // gentle drift wrap-around
      if (p.x < -10) p.x = width + 10; else if (p.x > width + 10) p.x = -10;
      if (p.y < -10) p.y = height + 10; else if (p.y > height + 10) p.y = -10;

      const glow = 0.7 + Math.random() * 0.3;
      ctx.fillStyle = `rgba(120, 200, 255, ${0.5 * glow})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }

    requestAnimationFrame(step);
  }

  window.addEventListener("resize", resize);
  resize();
  step();
})();

// Reveal-on-scroll using IntersectionObserver
document.addEventListener("DOMContentLoaded", () => {
  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('in-view');
      });
    }, { threshold: 0.12 });
    reveals.forEach(el => io.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('in-view'));
  }
});
